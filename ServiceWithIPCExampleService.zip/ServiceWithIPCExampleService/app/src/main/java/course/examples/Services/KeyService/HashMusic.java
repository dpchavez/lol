package course.examples.Services.KeyService;

import java.util.Hashtable;

public class HashMusic {
    Hashtable musicURL;

    public HashMusic(){
        musicURL = new Hashtable();
        musicURL.put(0,"https://open.spotify.com/track/0TCmhnbMpw5zwPsTvlXTJi?si=54194da53a364e7b");
        musicURL.put(1,"https://open.spotify.com/track/6vFsBXYczYsP0H3lgunZOm?si=388e0c66d9c149f0");
        musicURL.put(2,"https://open.spotify.com/track/2HsKkeVWys5Ts20z3e5lT0?si=0cb4afe896a04a59"); //Tenderness - Jay Som
        musicURL.put(3,"https://open.spotify.com/track/3FAJ6O0NOHQV8Mc5Ri6ENp?si=8afebbedf5194ba0");//Heartbreak Anniversary - Giveon
        musicURL.put(4,"https://open.spotify.com/track/4rzw37fRwEoUDx7gulKKHN?si=30d27ecd35194efc"); //ad meliora - THE CHARM PARK

    }
}
